#pragma once
#include "Persoana.h"
using namespace std;

class Angajat: virtual public Persoana
{
public:
    int id_angajat;
    int salariu;
    void afisare();
    Angajat();
    Angajat(const int, const int);
    Angajat(const Angajat &);
    int getid_angajat();
    int getvenit();
};
