#pragma once
#include "Persoana.h"
using namespace std;

class Student: virtual public Persoana
{
public:
    int id_student;
    int n;
    int *note;
    void afisare();
    Student();
    Student(const int &, const int &,  int*);
    Student(const Student &);
    ~Student();
    int getid_student();
    int getn();
    int * getnote();
    int getvenit();
    int bursa();
};
