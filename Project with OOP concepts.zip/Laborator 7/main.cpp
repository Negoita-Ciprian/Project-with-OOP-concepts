#include "Persoana.h"
#include "Student.h"
#include "Angajat.h"
#include "Student_Angajat.h"
#include <typeinfo>
using namespace std;

Persoana *persoane[300];

int main()
{
    Angajat A (1222, 4500);
    int x=9;
    Student S(131243, 1, &x);
    Student_Angajat SA (S,A);
    persoane[0] = &A;
    persoane[1] = &S;
    persoane[2] = &SA;
    int N = 3;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < i; j++)
            if (persoane[i]->getvenit() < persoane[j]->getvenit())
                swap(persoane[i], persoane[j]);
    for (int i = 0; i < N; i++)
    {
        persoane[i]->afisare();
        cout << "Venit: " << persoane[i]->getvenit() << "\n\n";
    }

    return 0;
}
