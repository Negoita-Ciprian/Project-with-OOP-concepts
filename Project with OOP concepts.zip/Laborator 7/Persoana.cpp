#include "Persoana.h"

int Persoana::getvenit() {
	return 0;
}

void Persoana::afisare() {
}
