#pragma once
#include "Angajat.h"
#include "Student.h"

class Student_Angajat : public Student, public Angajat
{
public:
    Student_Angajat(const Student, const Angajat );
    void afisare();
    int getvenit();
};


