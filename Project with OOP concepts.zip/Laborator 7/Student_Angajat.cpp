#include "Student_Angajat.h"

Student_Angajat::Student_Angajat(Student S, Angajat A):Student(S),Angajat(A)
{

}


int Student_Angajat::getvenit()
{
    return bursa()+ salariu;
}


void Student_Angajat::afisare()
{
	cout << "STUDENT ANGAJAT\n";
    Angajat::afisare();
    Student::afisare();
}

