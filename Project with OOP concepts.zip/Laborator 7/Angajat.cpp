#include "Angajat.h"

void Angajat::afisare()
{
    cout<<"ANGAJAT id: "<<id_angajat << '\n';
    cout<<"Salariu: "<<salariu << '\n';
}


Angajat::Angajat(const int ID_ANGAJAT, const int SALARIU)
{
    salariu = SALARIU;
    id_angajat = ID_ANGAJAT;
}


Angajat::Angajat(const Angajat &P)
{
    salariu = P.salariu;
    id_angajat = P.id_angajat;
}


Angajat::Angajat()
{
    id_angajat=0;
    salariu=0;
}


int Angajat::getid_angajat()
{
    return id_angajat;
}


int Angajat::getvenit()
{
    return salariu;
}
