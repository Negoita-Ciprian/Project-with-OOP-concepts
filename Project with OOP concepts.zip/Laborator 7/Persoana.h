#pragma once
#include <iostream>

using namespace std;

class Persoana
{
public:

	virtual int getvenit();
	virtual void afisare();
};

