#include "Student.h"

void Student::afisare()
{


    cout << "STUDENT id: " << id_student << '\n';
    cout << "Numar note: " << n << '\n';
    cout << "Note: ";
    for(int i=0; i<n; i++)
    {
        cout<<note[i]<<' ';

    }
    cout << '\n';
}

Student::Student(const int & ID_STUDENT, const int & N,  int *NOTE)
{
    n = N;
    id_student = ID_STUDENT;
    note = new int [n];
    for(int i=0; i<n; i++)
    {
        note[i]=NOTE[i];
    }

}


Student::Student(const Student &P)
{
    n = P.n;
    id_student = P.id_student;
    note= new int [n];
    for(int i=0; i<n; i++)
    {
        note[i]=P.note[i];
    }

}

Student::Student()
{
    n=0;
    id_student=0;

}

Student::~Student()
{

    delete[] note;

}


int Student::getid_student()
{
    return id_student;
}


int Student::getn()
{
    return n;
}


int * Student::getnote()
{
    return note;
}


int Student::bursa()
{
    int s=0;
    for(int i=0; i<n; i++)
    {
        s=s+note[i];
    }
    int medie=s/n;
    int ok=0;
    for(int i=0; i<n; i++)
    {
        if(note[i]<5 || medie<8.5)
            ok++;
    }
    if(ok==0)
        return 700;
    return 0;
}


int Student::getvenit()
{
    return bursa();
}
